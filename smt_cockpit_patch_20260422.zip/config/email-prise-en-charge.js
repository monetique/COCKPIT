// config/email-prise-en-charge.js
// Template email de prise en charge — modèle validé ClicToPay
// Inclut : paramètres d'accès TEST + cahier de recettes en pièce jointe (JSZip)
const path = require('path');
const fs   = require('fs');

// ── Génération de la référence dossier ───────────────────
function generateRef(processingId) {
  const now   = new Date();
  const d     = now.toISOString().slice(0,10).replace(/-/g,'');
  const short = (processingId || '').slice(-4).toUpperCase();
  const rand  = Math.random().toString(36).slice(2,6).toUpperCase();
  return `CTP-${d}-${short}-${rand}`;
}

// ── Paramètres TEST par défaut ────────────────────────────
const TEST_PARAMS = {
  apiUrl       : process.env.CTP_TEST_API_URL      || 'https://test.clictopay.com/payment/rest',
  monitoringUrl: process.env.CTP_TEST_MONITOR_URL  || 'https://test.clictopay.com/epg_gui/',
  supportEmail : process.env.CTP_SUPPORT_EMAIL     || 'webmaster@clictopay.com',
  logoUrl      : process.env.CTP_LOGO_URL          || '',
  website      : process.env.CTP_WEBSITE           || 'www.clictopay.com',
};

// ── Générer les credentials TEST pour un marchand ────────
function generateTestCredentials(processingId, terminalId) {
  // Règle : userName = terminal_id si disponible, sinon processing_id
  const apiUserName = (terminalId && terminalId.trim()) ? terminalId.trim() : processingId;
  // Mot de passe aléatoire 8 chars (1 maj + 2 chiffres + reste)
  const chars   = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz';
  const digits  = '23456789';
  let pwd = '';
  pwd += chars[Math.floor(Math.random() * 26)]; // 1 majuscule
  pwd += digits[Math.floor(Math.random() * 8)]; // 1 chiffre
  pwd += digits[Math.floor(Math.random() * 8)]; // 1 chiffre
  for (let i = 0; i < 5; i++) {
    pwd += chars[Math.floor(Math.random() * chars.length)];
  }
  pwd = pwd.split('').sort(() => Math.random() - 0.5).join('');

  const apiUser     = apiUserName;
  const apiPwd      = pwd;
  const monitorUser = `${apiUserName}_OP`;
  const monitorPwd  = pwd.split('').reverse().join('').slice(0,8);

  return { apiUser, apiPwd, monitorUser, monitorPwd };
}

// ── Construire le cahier de recettes pré-rempli (xlsx) ───
// Utilise JSZip (déjà installé) — sauvegarde dans cahiers_outbox
async function buildCahierRecettes(merchant, ref, creds) {

  console.log('[cahier] Début génération pour', merchant.processing_id, '| ref:', ref);

  // ── 1. Localiser le template ────────────────────────────
  const ROOT = path.join(__dirname, '..');
  const candidates = [
    path.join(ROOT, 'CahierDesRecettes_TEMPLATE.xlsx'),
    path.join(ROOT, 'cahiers_inbox', 'CahierDesRecettes_TEMPLATE.xlsx'),
    path.join(process.cwd(), 'CahierDesRecettes_TEMPLATE.xlsx'),
  ];

  let srcPath = null;
  for (const p of candidates) {
    console.log('[cahier] Cherche template :', p, '->', fs.existsSync(p) ? '✅' : '❌');
    if (fs.existsSync(p)) { srcPath = p; break; }
  }

  if (!srcPath) {
    console.error('[cahier] ❌ Template introuvable — copiez CahierDesRecettes_TEMPLATE.xlsx dans', ROOT);
    return null;
  }
  console.log('[cahier] Template trouvé :', srcPath);

  // ── 2. Créer le répertoire cahiers_outbox ───────────────
  const OUTBOX = path.join(ROOT, 'cahiers_outbox');
  if (!fs.existsSync(OUTBOX)) {
    fs.mkdirSync(OUTBOX, { recursive: true });
    console.log('[cahier] Répertoire créé :', OUTBOX);
  }

  // ── 3. Charger JSZip ────────────────────────────────────
  let JSZip;
  try {
    JSZip = require('jszip');
    console.log('[cahier] JSZip chargé via require');
  } catch(e1) {
    console.warn('[cahier] require(jszip) échoué:', e1.message, '— tentative chemin absolu');
    try {
      JSZip = require(path.join(ROOT, 'node_modules', 'jszip'));
      console.log('[cahier] JSZip chargé via chemin absolu');
    } catch(e2) {
      console.error('[cahier] ❌ JSZip introuvable :', e2.message, '— lancez: npm install jszip');
      return null;
    }
  }

  // ── 4. Lire et patcher le xlsx ──────────────────────────
  try {
    const rawBuffer = fs.readFileSync(srcPath);
    console.log('[cahier] Template lu :', rawBuffer.length, 'bytes');

    const zip = await JSZip.loadAsync(rawBuffer);
    const xmlFiles = Object.keys(zip.files).filter(f =>
      !zip.files[f].dir && (f.endsWith('.xml') || f.endsWith('.rels'))
    );
    console.log('[cahier] Fichiers XML dans le zip :', xmlFiles.length);

    // Échapper XML
    const esc = s => String(s || '')
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&apos;');

    const replacements = {
      '{{RAISON_SOCIALE}}' : esc(merchant.raison_sociale || ''),
      '{{PROCESSING_ID}}'  : esc(merchant.processing_id  || ''),
      '{{TERMINAL_ID}}'    : esc(merchant.terminal_id    || ''),
      '{{MCC}}'            : esc(merchant.mcc            || ''),
      '{{SITE_URL}}'       : esc(merchant.site_web       || ''),
      '{{EMAIL}}'          : esc(merchant.email_contact  || ''),
      '{{TRACKING_REF}}'   : esc(ref                     || ''),
      '{{API_URL}}'        : esc(TEST_PARAMS.apiUrl),
      '{{API_USER}}'       : esc(creds.apiUser),
      '{{API_PWD}}'        : esc(creds.apiPwd),
      '{{MONITORING_URL}}' : esc(TEST_PARAMS.monitoringUrl),
      '{{MONITOR_USER}}'   : esc(creds.monitorUser),
      '{{MONITOR_PWD}}'    : esc(creds.monitorPwd),
    };

    let totalReplacements = 0;
    for (const filename of xmlFiles) {
      let content = await zip.files[filename].async('string');
      let changed = false;
      for (const [ph, val] of Object.entries(replacements)) {
        if (content.includes(ph)) {
          content = content.split(ph).join(val);
          changed = true;
          totalReplacements++;
        }
      }
      if (changed) zip.file(filename, content);
    }
    console.log('[cahier] Total remplacements :', totalReplacements);

    // ── 5. Générer le buffer final ──────────────────────
    const outBuffer = await zip.generateAsync({ type:'nodebuffer', compression:'DEFLATE' });
    console.log('[cahier] Buffer généré :', outBuffer.length, 'bytes');

    // ── 6. Sauvegarder dans cahiers_outbox ──────────────
    const filename  = `CahierDesRecettes_${merchant.processing_id}_${ref}.xlsx`;
    const outPath   = path.join(OUTBOX, filename);
    fs.writeFileSync(outPath, outBuffer);
    console.log('[cahier] ✅ Sauvegardé dans outbox :', outPath);

    return {
      filename,
      content    : outBuffer,
      contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    };

  } catch(e) {
    console.error('[cahier] ❌ Erreur génération :', e.message);
    console.error(e.stack);
    return null;
  }
}

// ── Template HTML email ───────────────────────────────────
function buildEmailHTML(merchant, ref, creds) {
  const apiBase  = TEST_PARAMS.apiUrl;
  const monUrl   = TEST_PARAMS.monitoringUrl;
  const support  = TEST_PARAMS.supportEmail;
  const website  = TEST_PARAMS.website;
  const logoUrl  = TEST_PARAMS.logoUrl;

  // Image du logo : URL distante ou fallback texte
  const logoHtml = logoUrl
    ? `<img src="${logoUrl}" alt="ClicToPay" style="height:46px;width:auto;display:block;">`
    : `<span style="font-size:20px;font-weight:800;color:#1e3a8a;letter-spacing:-0.5px;">ClicToPay</span>`;

  return `<!DOCTYPE html><html lang="fr"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<style>
  *{margin:0;padding:0;box-sizing:border-box;}
  body{font-family:'Helvetica Neue',Arial,sans-serif;background:#eef2f7;color:#1a2340;}
  .outer{max-width:720px;margin:32px auto;padding:0 12px;}

  /* Header */
  .hdr{background:#ffffff;border-radius:10px 10px 0 0;padding:24px 36px;
       border-bottom:1px solid #e8ecf1;text-align:left;
       display:table;width:100%;}
  .hdr-left{display:table-cell;vertical-align:middle;}
  .hdr-right{display:table-cell;vertical-align:middle;text-align:right;
             font-size:10px;color:#94a3b8;font-family:'Courier New',monospace;}

  /* Ref bar */
  .ref-bar{background:linear-gradient(90deg,#1e3a8a,#2563eb);
           color:#fff;padding:9px 36px;font-size:11px;
           font-family:'Courier New',monospace;letter-spacing:.3px;}
  .ref-bar b{font-weight:700;}

  /* Body */
  .body{background:#ffffff;padding:28px 36px;}
  .greeting{font-size:15px;font-weight:700;color:#1a2340;margin-bottom:10px;}
  .intro{font-size:13px;color:#475569;line-height:1.75;margin-bottom:22px;}

  /* Section */
  .sec{margin-bottom:22px;border-radius:6px;overflow:hidden;border:1px solid #e2e8f0;}
  .sec-hdr{padding:9px 14px;font-size:10.5px;font-weight:700;
           text-transform:uppercase;letter-spacing:.7px;color:#fff;}
  .sec-hdr.blue  {background:#2563eb;}
  .sec-hdr.green {background:#16a34a;}
  .sec-hdr.navy  {background:#1e3a8a;}
  .sec-hdr.amber {background:#d97706;}
  .sec-hdr.slate {background:#475569;}
  .sec-body{background:#fff;}

  /* Table params */
  table.tp{width:100%;border-collapse:collapse;}
  table.tp tr:last-child td{border-bottom:none;}
  table.tp td{padding:8px 14px;border-bottom:1px solid #f1f5f9;font-size:12.5px;}
  table.tp td.lbl{color:#64748b;width:44%;font-weight:500;background:#fafbfc;}
  table.tp td.val{font-family:'Courier New',monospace;color:#1a2340;font-weight:700;
                  word-break:break-all;}
  table.tp td.url{color:#2563eb !important;font-size:11.5px;}
  table.tp td.pwd{color:#dc2626 !important;}

  /* Cartes de test */
  .cards-wrap{display:table;width:100%;}
  .card-col{display:table-cell;width:50%;padding:12px 14px;vertical-align:top;
            border-right:1px solid #f1f5f9;}
  .card-col:last-child{border-right:none;}
  .card-badge{display:inline-block;padding:2px 8px;border-radius:20px;
              font-size:10px;font-weight:700;margin-bottom:7px;}
  .badge-ok{background:#dcfce7;color:#15803d;}
  .badge-ko{background:#fee2e2;color:#dc2626;}
  .card-row{font-size:11.5px;padding:2px 0;color:#475569;}
  .card-row b{color:#1a2340;font-family:'Courier New',monospace;}

  /* Steps */
  .steps{padding:0;}
  .step-row{display:table;width:100%;padding:10px 14px;
            border-bottom:1px solid #f1f5f9;}
  .step-row:last-child{border-bottom:none;}
  .step-num-cell{display:table-cell;vertical-align:top;width:28px;}
  .step-num{width:22px;height:22px;border-radius:50%;background:#2563eb;
            color:#fff;font-size:10px;font-weight:700;text-align:center;
            line-height:22px;font-family:'Courier New',monospace;}
  .step-content{display:table-cell;vertical-align:top;padding-left:8px;}
  .step-title{font-size:12.5px;font-weight:700;color:#1a2340;margin-bottom:3px;}
  .step-desc{font-size:12px;color:#475569;line-height:1.65;}
  .code{font-family:'Courier New',monospace;background:#eff6ff;padding:1px 5px;
        border-radius:3px;color:#2563eb;font-size:11px;}
  .param-list{margin:5px 0 0 0;padding:0;list-style:none;}
  .param-list li{font-size:11.5px;color:#475569;padding:1px 0;}
  .param-list li b{color:#1a2340;}

  /* Alertes */
  .warn{background:#fff7ed;border-left:3px solid #f59e0b;
        padding:10px 14px;font-size:12px;color:#92400e;margin-bottom:16px;border-radius:0 4px 4px 0;}
  .danger{background:#fef2f2;border-left:3px solid #dc2626;
          padding:10px 14px;font-size:12px;color:#991b1b;margin-bottom:16px;border-radius:0 4px 4px 0;}
  .info{background:#eff6ff;border-left:3px solid #2563eb;
        padding:10px 14px;font-size:12px;color:#1e40af;margin-bottom:16px;border-radius:0 4px 4px 0;}

  /* Contact */
  .contact{background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;
           padding:12px 14px;font-size:12.5px;color:#475569;margin-bottom:18px;}
  .contact a{color:#2563eb;font-weight:700;text-decoration:none;}

  /* Signature */
  .sign{font-size:13px;color:#475569;padding-top:16px;border-top:1px solid #e8ecf1;line-height:1.7;}
  .sign a{color:#2563eb;text-decoration:none;font-size:12px;}

  /* Footer */
  .ftr{background:#1e3a8a;border-radius:0 0 10px 10px;
       padding:12px 36px;text-align:center;font-size:10.5px;
       color:#93c5fd;font-family:'Courier New',monospace;}
  .ftr b{color:#fff;}
</style>
</head>
<body>
<div class="outer">

  <!-- HEADER -->
  <div class="hdr">
    <div class="hdr-left">${logoHtml}</div>
    <div class="hdr-right">Plateforme de paiement<br>en ligne sécurisée</div>
  </div>
  <div class="ref-bar">Référence de suivi : <b>${ref}</b></div>

  <!-- BODY -->
  <div class="body">
    <p class="greeting">Madame, Monsieur,</p>
    <p class="intro">
      Nous sommes ravis de vous accueillir sur la plateforme de paiement en ligne
      <strong>ClicToPay</strong> et vous remercions chaleureusement pour votre confiance.<br><br>
      Votre espace marchand <strong>${merchant.raison_sociale}</strong>
      a été créé avec succès. Vous trouverez ci-dessous vos paramètres d'accès
      à l'environnement de test <strong>(sandbox)</strong>.
    </p>

    <!-- Espace Marchand -->
    <div class="sec">
      <div class="sec-hdr navy">🏪 &nbsp;Votre Espace Marchand</div>
      <div class="sec-body">
        <table class="tp">
          <tr><td class="lbl">Raison sociale</td><td class="val">${merchant.raison_sociale}</td></tr>
          <tr><td class="lbl">Processing ID</td><td class="val">${merchant.processing_id}</td></tr>
          ${merchant.terminal_id ? `<tr><td class="lbl">Terminal ID</td><td class="val">${merchant.terminal_id}</td></tr>` : ''}
        </table>
      </div>
    </div>

    <!-- API TEST -->
    <div class="sec">
      <div class="sec-hdr blue">🔗 &nbsp;API Paiement — Environnement TEST</div>
      <div class="sec-body">
        <table class="tp">
          <tr><td class="lbl">Endpoint API</td><td class="val url">${apiBase}/register.do</td></tr>
          <tr><td class="lbl">Nom d'utilisateur</td><td class="val">${creds.apiUser}</td></tr>
          <tr><td class="lbl">Mot de passe</td><td class="val pwd">${creds.apiPwd}</td></tr>
        </table>
      </div>
    </div>

    <!-- Portail Monitoring TEST -->
    <div class="sec">
      <div class="sec-hdr green">📊 &nbsp;Portail Monitoring — Environnement TEST</div>
      <div class="sec-body">
        <table class="tp">
          <tr><td class="lbl">URL du portail</td><td class="val url">${monUrl}</td></tr>
          <tr><td class="lbl">Nom d'utilisateur</td><td class="val">${creds.monitorUser}</td></tr>
          <tr><td class="lbl">Mot de passe</td><td class="val pwd">${creds.monitorPwd}</td></tr>
        </table>
      </div>
    </div>

    <!-- Sécurité -->
    <div class="warn">
      ⚠️ <strong>Sécurité — Action requise :</strong> Ces identifiants sont strictement confidentiels.
      Modifiez vos mots de passe dès votre première connexion.
    </div>

    <!-- Cartes de test -->
    <div class="sec">
      <div class="sec-hdr amber">💳 &nbsp;Cartes de Test Disponibles</div>
      <div class="sec-body">
        <div class="cards-wrap">
          <div class="card-col">
            <span class="card-badge badge-ok">✅ Paiement accepté</span>
            <div class="card-row">N° carte &nbsp;<b>4509 2111 1111 1119</b></div>
            <div class="card-row">Expiration &nbsp;<b>12/26</b></div>
            <div class="card-row">CVV &nbsp;<b>748</b></div>
          </div>
          <div class="card-col">
            <span class="card-badge badge-ko">❌ Paiement refusé</span>
            <div class="card-row">N° carte &nbsp;<b>5104 0511 1111 1115</b></div>
            <div class="card-row">Expiration &nbsp;<b>12/29</b></div>
            <div class="card-row">CVV &nbsp;<b>749</b></div>
          </div>
        </div>
        <div style="padding:8px 14px;font-size:11px;color:#64748b;border-top:1px solid #f1f5f9;">
          Ces cartes sont à usage exclusif dans l'environnement sandbox.
        </div>
      </div>
    </div>

    <!-- Phase 1 : Intégration -->
    <div class="sec">
      <div class="sec-hdr slate">🔧 &nbsp;Phase 1 — Intégration &amp; Tests (Obligatoire)</div>
      <div class="sec-body steps">
        <div class="step-row">
          <div class="step-num-cell"><div class="step-num">1</div></div>
          <div class="step-content">
            <div class="step-title">Initialisation — <span class="code">register.do</span></div>
            <ul class="param-list">
              <li><b>userName</b> (AN..30) — Login marchand</li>
              <li><b>password</b> (AN..30) — Mot de passe marchand</li>
              <li><b>orderNumber</b> (AN..32) — Identifiant de commande</li>
              <li><b>amount</b> (N..20) — Montant en millimes</li>
              <li><b>currency</b> (N..3) — Code ISO 4217 (788 = TND)</li>
              <li><b>returnUrl</b> (AN..512) — URL après succès</li>
              <li><b>failUrl</b> (AN..512) — URL après échec</li>
            </ul>
          </div>
        </div>
        <div class="step-row">
          <div class="step-num-cell"><div class="step-num">2</div></div>
          <div class="step-content">
            <div class="step-title">Redirection client</div>
            <div class="step-desc">Le client est redirigé vers la page de paiement ClicToPay pour saisir ses informations et valider.</div>
          </div>
        </div>
        <div class="step-row">
          <div class="step-num-cell"><div class="step-num">3</div></div>
          <div class="step-content">
            <div class="step-title">⚠️ Vérification du statut — <span class="code">getOrderStatusExtended.do</span></div>
            <div class="step-desc">
              À appeler <strong>uniquement après la redirection</strong> du client — jamais juste après <span class="code">register.do</span>.
            </div>
          </div>
        </div>
        <div class="step-row">
          <div class="step-num-cell"><div class="step-num">4</div></div>
          <div class="step-content">
            <div class="step-title">Décision selon le statut</div>
            <div class="step-desc">
              <b>orderStatus = 2</b> → Paiement autorisé → returnUrl<br>
              <b>Autre valeur</b> → Paiement échoué → failUrl
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Erreur fréquente -->
    <div class="danger">
      🚫 <strong>Erreur fréquente :</strong> Ne jamais rediriger vers une page de succès sans avoir
      vérifié le statut via <strong>getOrderStatusExtended.do</strong>.
    </div>

    <!-- Tests -->
    <div class="info">
      🧪 <strong>Tests à réaliser :</strong> Paiement accepté · Paiement refusé ·
      Redirections returnUrl / failUrl · Statuts via API
    </div>

    <!-- Phase 2 : Production -->
    <div class="sec">
      <div class="sec-hdr green">🚀 &nbsp;Phase 2 — Passage en Production</div>
      <div class="sec-body" style="padding:12px 14px;font-size:12.5px;color:#475569;line-height:1.75;">
        Une fois vos tests validés, notre équipe procédera à la validation technique de votre intégration.
        Après l'envoi de la grille de validation, merci de prévoir un délai d'une semaine.
        Sans retour de notre part, nous vous invitons à nous adresser un e-mail de relance.
      </div>
    </div>

    <!-- Contact -->
    <div class="contact">
      📩 <strong>Support technique :</strong>
      Pour toute assistance, contactez-nous à
      <a href="mailto:${support}">${support}</a>
    </div>

    <div class="sign">
      Nous vous souhaitons une excellente intégration et restons à votre disposition.<br><br>
      Cordialement,<br>
      <strong>L'équipe ClicToPay</strong><br>
      <a href="https://www.clictopay.com">www.clictopay.com</a>
    </div>
  </div>

  <!-- FOOTER -->
  <div class="ftr">
    <b>ClicToPay</b> · Monetique Tunisie · ${new Date().getFullYear()} · Réf. <b>${ref}</b>
  </div>

</div>
</body>
</html>`;
}

module.exports = { generateRef, generateTestCredentials, buildCahierRecettes, buildEmailHTML, TEST_PARAMS };
